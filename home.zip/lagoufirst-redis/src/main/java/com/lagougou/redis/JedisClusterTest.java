package com.lagougou.redis;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class JedisClusterTest {


    public static void main(String[] args) {

        JedisPoolConfig config = new JedisPoolConfig();

        Set<HostAndPort> nodeList = new HashSet<>();
        nodeList.add(new HostAndPort("192.168.31.142", 7001));
        nodeList.add(new HostAndPort("192.168.31.142", 7002));
        nodeList.add(new HostAndPort("192.168.31.142", 7003));
        nodeList.add(new HostAndPort("192.168.31.142", 7004));
        nodeList.add(new HostAndPort("192.168.31.142", 7005));
        nodeList.add(new HostAndPort("192.168.31.142", 7006));
        nodeList.add(new HostAndPort("192.168.31.142", 7007));
        nodeList.add(new HostAndPort("192.168.31.142", 7008));

        JedisCluster jedisCluster = new JedisCluster(nodeList, 3000, config);
        Map<String, JedisPool> nodes = jedisCluster.getClusterNodes();
        jedisCluster.set("name:007", "joker");
        String value = jedisCluster.get("name:007");

        System.out.println(value);
    }




}
