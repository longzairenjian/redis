package com.lagougou.lagoufirstredisjediscluster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LagoufirstRedisJedisclusterApplicationTests {

    @Test
    void contextLoads() {
    }

}
